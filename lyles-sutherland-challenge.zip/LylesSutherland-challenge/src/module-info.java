module challenge {
	requires org.junit.jupiter.api;
}